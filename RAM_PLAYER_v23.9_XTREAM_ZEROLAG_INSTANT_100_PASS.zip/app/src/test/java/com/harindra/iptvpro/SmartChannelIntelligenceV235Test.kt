package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.5 — Automated Unit Tests for SmartChannelIntelligenceEngine,
 * Bounded Recovery (Zero Infinite Retry), HTTP 401/403/404/429/5xx Policies,
 * 50x Rapid Zapping Session Cancellation, 1000+ Channel Pre-Analysis & 512MB Adaptive Buffering.
 */
class SmartChannelIntelligenceV235Test {

    @Test
    fun http401And403StopImmediatelyWithZeroRetries() {
        for (code in listOf(401, 403)) {
            val d = SmartChannelIntelligenceEngine.classifyPlaybackError(
                httpStatusCode = code,
                errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
                message = "Response code: $code",
                engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
            )
            assertEquals(ChannelPlaybackResult.UNAVAILABLE, d.result)
            assertEquals(ErrorRecoveryAction.NONE_STOP, d.action)
            assertEquals(0, d.maxRetries)
        }
    }

    @Test
    fun http404TriesBackupOnceThenStopsWithoutLooping() {
        val session = BoundedRecoverySession(sessionToken = 1L, channelKey = "ch_404")
        val raw = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 404,
            errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
            message = "Response code: 404",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        val first = session.evaluateDecision(raw, hasBackupUrl = true)
        assertEquals(ErrorRecoveryAction.TRY_BACKUP_URL_ONCE, first.action)
        assertTrue(session.markBackupUrlTried("http://xtream.example:8080/live/u/p/404.ts"))

        val second = session.evaluateDecision(raw, hasBackupUrl = true)
        assertEquals(ErrorRecoveryAction.NONE_STOP, second.action)
    }

    @Test
    fun http429AppliesRateLimitCooldownAndMaxOneRetry() {
        val session = BoundedRecoverySession(sessionToken = 2L, channelKey = "ch_429")
        val raw = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 429,
            errorCodeName = "ERROR_CODE_IO_BAD_HTTP_STATUS",
            message = "Too Many Requests",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        assertEquals(8000L, raw.cooldownMs)
        val first = session.evaluateDecision(raw, hasBackupUrl = false)
        assertEquals(ErrorRecoveryAction.RETRY_WITH_COOLDOWN, first.action)
        session.recordErrorFingerprint(raw.errorFingerprint)
        assertTrue(session.commitRecoveryAction("retry_429_1", CommittedRecoveryType.RETRY))

        val second = session.evaluateDecision(raw, hasBackupUrl = false)
        assertEquals(ErrorRecoveryAction.NONE_STOP, second.action)
    }

    @Test
    fun codecFailureAllowsAtMostOneEngineSwitchPerSession() {
        val session = BoundedRecoverySession(sessionToken = 3L, channelKey = "sony_max_hd")
        val raw = SmartChannelIntelligenceEngine.classifyPlaybackError(
            httpStatusCode = 0,
            errorCodeName = "ERROR_CODE_DECODER_INIT_FAILED",
            message = "MediaCodecAudioRenderer ac3 failed",
            engineMode = LiveTvEngineMode.AUTO_OTT_HEAL
        )
        val first = session.evaluateDecision(raw, hasBackupUrl = false)
        assertEquals(ErrorRecoveryAction.SWITCH_ENGINE_ONCE, first.action)
        assertTrue(session.canSwitchEngine())
        session.markEngineSwitched()
        assertFalse(session.canSwitchEngine())

        val second = session.evaluateDecision(raw, hasBackupUrl = false)
        assertEquals(ErrorRecoveryAction.NONE_STOP, second.action)
        assertEquals(ChannelPlaybackResult.UNSUPPORTED, second.result)
    }

    @Test
    fun rapid50ChannelZappingAnd1000ChannelRoutingStayBounded() {
        var latestToken = 0L
        val sessions = ArrayList<BoundedRecoverySession>(50)
        for (i in 1..50) {
            latestToken++
            sessions.add(BoundedRecoverySession(latestToken, "ch_$i"))
        }
        assertEquals(50L, latestToken)
        // Old sessions (1..49) have stale tokens compared to active session 50
        assertTrue(sessions.take(49).all { it.sessionToken != latestToken })

        // Pre-analyze 1200 mixed Xtream + M3U + RTMP channels quickly
        var directVlcCount = 0
        for (i in 1..1200) {
            val url = when {
                i % 10 == 0 -> "rtmp://live.example/app/ch$i"
                i % 5 == 0 -> "http://xtream.example:8080/live/u/p/$i.ts"
                else -> "http://xtream.example:8080/live/u/p/$i.m3u8"
            }
            val rem = if (i == 343) LiveTvHealStage.VLC_HW_BACKUP.name else null
            val chosen = SmartChannelIntelligenceEngine.chooseInitialEngine(url, LiveTvEngineMode.AUTO_OTT_HEAL, rem)
            if (chosen == LiveTvEngineMode.LIBVLC_HW) directVlcCount++
        }
        assertEquals(121, directVlcCount) // 120 RTMP + 1 remembered Sony Max HD (343)
    }

    @Test
    fun adaptiveBufferingStartsFastAndCapsSafelyFor512MbTv() {
        val fastStart512 = SmartChannelIntelligenceEngine.computeAdaptiveLibVlcCacheMs(
            isLowRamDevice = true,
            rebufferEventsInSession = 0,
            isDegradedNetwork = false
        )
        val afterRebuffers512 = SmartChannelIntelligenceEngine.computeAdaptiveLibVlcCacheMs(
            isLowRamDevice = true,
            rebufferEventsInSession = 10,
            isDegradedNetwork = true
        )
        assertEquals(SmartChannelIntelligenceEngine.LOW_RAM_STARTUP_CACHE_MS, fastStart512)
        assertEquals(SmartChannelIntelligenceEngine.LOW_RAM_MAX_CACHE_MS, afterRebuffers512)
    }
}
