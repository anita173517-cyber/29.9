package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.GZIPOutputStream

/**
 * RAM PLAYER v23.3 — Storage Optimization, LRU Cache Pruning, GZIP Compression & Fast-Start Tests.
 */
class StorageOptimizationV233Test {

    @Test
    fun lruPruningEnforcesExactMaxByteCapAndKeepsNewestFiles() {
        val tempDir = Files.createTempDirectory("ram_player_lru_test").toFile()
        try {
            val files = ArrayList<File>()
            val baseTime = System.currentTimeMillis() - 100_000L
            for (i in 1..10) {
                val f = File(tempDir, "logo_$i.img")
                f.writeBytes(ByteArray(1024 * 100)) // 100 KB each -> 1000 KB total
                f.setLastModified(baseTime + i * 1000L)
                files.add(f)
            }
            val capBytes = 350L * 1024L
            val (freed, deleted) = StorageBudgetManager.pruneDirectoryLru(tempDir, capBytes)
            assertTrue("Expected at least 650KB freed", freed >= 650L * 1024L)
            assertEquals(7, deleted)
            val remaining = tempDir.listFiles()?.map { it.name }?.toSet().orEmpty()
            assertEquals(setOf("logo_8.img", "logo_9.img", "logo_10.img"), remaining)
            assertTrue(StorageBudgetManager.measureDirectoryBytes(tempDir) <= capBytes)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun gzipCompressionShrinksLarge1500ChannelPlaylistByOver75Percent() {
        val sb = StringBuilder(200_000)
        sb.append("SXB2\n")
        for (i in 1..1500) {
            sb.append("ch_").append(i).append('\t')
                .append(i).append('\t')
                .append("IN: SONY MAX HD ").append(i).append('\t')
                .append("INDIA | HINDI MOVIES").append('\t')
                .append("http://iptv.provider.example:8080/live/user123/pass456/").append(10000 + i).append(".m3u8\t")
                .append("http://cdn.provider.example/logos/sony_max_hd.png\t")
                .append("sonymax.in\t")
                .append("http://iptv.provider.example:8080/live/user123/pass456/").append(10000 + i).append(".ts\t")
                .append("XTREAM_LIVE\t12\tm3u8\t\t\t\n")
        }
        val rawBytes = sb.toString().toByteArray(Charsets.UTF_8)
        val baos = ByteArrayOutputStream()
        GZIPOutputStream(baos).use { it.write(rawBytes) }
        val compressedBytes = baos.toByteArray()

        val ratio = compressedBytes.size.toDouble() / rawBytes.size.toDouble()
        assertTrue("Expected >75% GZIP savings on 1500-channel catalog (ratio=$ratio)", ratio < 0.25)
    }

    @Test
    fun storageBudgetConstantsStayUnder60MbTotalLimit() {
        assertTrue(StorageBudgetManager.MAX_GLIDE_DISK_CACHE_BYTES <= 4L * StorageBudgetManager.MB)
        assertTrue(StorageBudgetManager.MAX_TOTAL_CACHE_BUDGET_BYTES <= 12L * StorageBudgetManager.MB)
        assertEquals("24.0 MB", StorageBudgetManager.formatSize(24L * StorageBudgetManager.MB))
        assertEquals("512 KB", StorageBudgetManager.formatSize(512L * 1024L))
    }
}
