package com.harindra.iptvpro

import android.content.Context
import android.util.JsonReader
import android.util.JsonToken
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.zip.GZIPOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.coroutineContext

/**
 * Ultra-Fast Source-Aware Channel & VOD Cache Store for 512MB RAM Android TVs (v18.1 Correct VOD Edition).
 *
 * - Level 1: Isolated In-Memory RAM Cache per catalog key (`live_<profile>`, `vod_<profile>`, `series_<profile>`),
 *   trimmable on low RAM without ever mixing Live TV, Movies, or Series across accounts.
 * - Level 2: SXB2 Line-Stream Fast Binary/Tabbed Disk Format (64KB I/O buffers, zero Regex allocation),
 *   persisting explicit [ContentSourceType] and provider metadata fields.
 * - Backward-compatible with existing 8-column SXB2 and legacy JSON cache files.
 */
class ChannelCacheStore(context: Context) {
    private val appContext = context.applicationContext
    private val cacheMutex = Mutex()

    companion object {
        private const val CACHE_PREFIX = "streamx_channel_cache_"
        private const val FAST_HEADER = "SXB2"
        private const val FIRST_BATCH_SIZE = 40
        private const val MAX_CACHE_FILES = 9 // Allows Live + VOD + Series across up to 3 accounts
        private const val MAX_TOTAL_CACHE_BYTES = 18L * 1024L * 1024L // 18 MB bound for 512MB TVs
        private const val MAX_CACHED_CHANNELS = 60_000
        const val PLAYLIST_REFRESH_TTL_MS = 6L * 60L * 60L * 1000L // 6 hours background refresh TTL

        private val ramCacheByKey = ConcurrentHashMap<String, List<Channel>>(4)

        fun trimMemoryCache() {
            ramCacheByKey.clear()
        }

        private fun sanitizeKeyFast(raw: String): String {
            if (raw.isEmpty()) return "default"
            val limit = raw.length.coerceAtMost(64)
            val sb = StringBuilder(limit)
            for (i in 0 until limit) {
                val c = raw[i]
                if ((c in 'a'..'z') || (c in 'A'..'Z') || (c in '0'..'9') || c == '_' || c == '.' || c == '-') {
                    sb.append(c)
                } else {
                    sb.append('_')
                }
            }
            return if (sb.isEmpty()) "default" else sb.toString()
        }
    }

    init {
        runCatching {
            appContext.filesDir.listFiles()?.forEach { f ->
                if (f.name.endsWith(".tmp")) f.delete()
            }
        }
    }

    private fun cacheFileFor(key: String): File {
        val safeKey = sanitizeKeyFast(key)
        return File(appContext.filesDir, "$CACHE_PREFIX$safeKey.json")
    }

    fun isCacheStale(key: String, ttlMs: Long = PLAYLIST_REFRESH_TTL_MS): Boolean {
        val f = cacheFileFor(key)
        if (!f.exists() || f.length() <= 4L) return true
        return (System.currentTimeMillis() - f.lastModified()) > ttlMs
    }

    private fun cleanTabField(value: String): String {
        if (value.indexOf('\t') < 0 && value.indexOf('\n') < 0 && value.indexOf('\r') < 0) return value
        return value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()
    }

    suspend fun saveChannels(key: String, channels: List<Channel>, maxLimit: Int = MAX_CACHED_CHANNELS) {
        if (channels.isEmpty()) return
        if (ramCacheByKey.size >= 4 && !ramCacheByKey.containsKey(key)) {
            ramCacheByKey.clear()
        }
        ramCacheByKey[key] = channels
        withContext(Dispatchers.IO) {
            cacheMutex.withLock {
                val targetFile = cacheFileFor(key)
                val tempFile = File(appContext.filesDir, "${targetFile.name}.tmp")
                try {
                    FileOutputStream(tempFile).use { fos ->
                        BufferedWriter(OutputStreamWriter(GZIPOutputStream(fos), Charsets.UTF_8), 32768).use { writer ->
                            writer.write(FAST_HEADER)
                            writer.newLine()
                            val count = channels.size.coerceAtMost(maxLimit)
                            for (idx in 0 until count) {
                                if (idx % 2000 == 0) coroutineContext.ensureActive()
                                val ch = channels[idx]
                                writer.write(cleanTabField(ch.id))
                                writer.write('\t'.code)
                                writer.write(ch.number.toString())
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.name))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.category))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.streamUrl))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.logoUrl))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.epgId))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.backupUrl))
                                writer.write('\t'.code)
                                writer.write(ch.sourceType.code)
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.categoryId))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.containerExtension))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.releaseDate))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.rating))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.plot))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.cast))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.director))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.durationLabel))
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.trailerUrl))
                                writer.write('\t'.code)
                                writer.write(ch.addedTimestamp.toString())
                                writer.write('\t'.code)
                                writer.write(cleanTabField(ch.seriesId))
                                writer.newLine()
                            }
                            writer.flush()
                        }
                        runCatching { fos.fd.sync() }
                    }
                    if (tempFile.exists() && tempFile.length() > 4L) {
                        if (targetFile.exists()) {
                            targetFile.delete()
                        }
                        val renamed = tempFile.renameTo(targetFile)
                        if (!renamed) {
                            tempFile.copyTo(targetFile, overwrite = true)
                            tempFile.delete()
                        }
                        enforceCacheBounds(keepFile = targetFile)
                    } else {
                        tempFile.delete()
                    }
                } catch (e: Exception) {
                    tempFile.delete()
                    Log.w("StreamX", "Cache write aborted or failed for $key", e)
                }
                Unit
            }
        }
    }

    suspend fun loadChannels(
        key: String,
        maxLimit: Int = MAX_CACHED_CHANNELS,
        defaultSourceType: ContentSourceType = ContentSourceType.M3U_LIVE,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)? = null
    ): List<Channel> = withContext(Dispatchers.IO) {
        val ramHit = ramCacheByKey[key].orEmpty()
        if (ramHit.isNotEmpty()) {
            return@withContext ramHit
        }

        cacheMutex.withLock {
            val file = cacheFileFor(key)
            if (!file.exists() || file.length() <= 4L) return@withLock emptyList()
            try {
                BufferedReader(InputStreamReader(NetworkClient.openDecompressedStream(FileInputStream(file)), Charsets.UTF_8), 65536).use { reader ->
                    reader.mark(16)
                    val firstLine = reader.readLine() ?: return@withLock emptyList()
                    if (firstLine == FAST_HEADER) {
                        val loaded = parseFastSxb2Stream(reader, maxLimit, defaultSourceType, onFirstBatchReady)
                        if (loaded.isNotEmpty()) {
                            ramCacheByKey[key] = loaded
                        }
                        return@withLock loaded
                    }
                }
                val legacyLoaded = loadLegacyJsonCache(file, maxLimit, defaultSourceType, onFirstBatchReady)
                if (legacyLoaded.isNotEmpty()) {
                    ramCacheByKey[key] = legacyLoaded
                }
                legacyLoaded
            } catch (e: Exception) {
                Log.w("StreamX", "Corrupted or cancelled cache read for ${file.name}; removing file", e)
                runCatching { file.delete() }
                emptyList()
            }
        }
    }

    private suspend fun parseFastSxb2Stream(
        reader: BufferedReader,
        maxLimit: Int,
        defaultSourceType: ContentSourceType,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)?
    ): List<Channel> {
        val result = ArrayList<Channel>(4096)
        val categoryPool = HashMap<String, String>(128)
        var firstBatchDispatched = false
        var idx = 0

        var line: String? = reader.readLine()
        while (line != null && idx < maxLimit) {
            if (idx % 2000 == 0) coroutineContext.ensureActive()
            if (line.isNotEmpty()) {
                val cols = line.split('\t')
                if (cols.size >= 5) {
                    idx++
                    val id = cols[0].ifBlank { "ch_$idx" }
                    val num = cols[1].toIntOrNull() ?: idx
                    val name = cols[2].ifBlank { "Channel $idx" }
                    val rawCat = cols[3].ifBlank { "Live TV" }
                    val category = categoryPool.getOrPut(rawCat) { rawCat }
                    val streamUrl = cols[4]
                    val logoUrl = cols.getOrNull(5).orEmpty()
                    val epgId = cols.getOrNull(6).orEmpty()
                    val backupUrl = cols.getOrNull(7).orEmpty()
                    val srcCode = cols.getOrNull(8).orEmpty()
                    val resolvedSourceType = if (srcCode.isNotBlank()) {
                        ContentSourceType.fromCode(srcCode)
                    } else {
                        defaultSourceType
                    }
                    // Skip legacy polluted VOD/Series items if loading a Live TV cache
                    if (defaultSourceType.isLiveTv() && (id.startsWith("vod_") || id.startsWith("series_") || id.startsWith("ep_")) && srcCode.isBlank()) {
                        line = reader.readLine()
                        continue
                    }

                    if (streamUrl.isNotEmpty()) {
                        result.add(
                            Channel(
                                id = id,
                                number = if (num > 0) num else idx,
                                name = name,
                                category = category,
                                streamUrl = streamUrl,
                                logoUrl = logoUrl,
                                epgId = epgId,
                                backupUrl = backupUrl,
                                sourceType = resolvedSourceType,
                                categoryId = cols.getOrNull(9).orEmpty(),
                                containerExtension = cols.getOrNull(10).orEmpty(),
                                releaseDate = cols.getOrNull(11).orEmpty(),
                                rating = cols.getOrNull(12).orEmpty(),
                                plot = cols.getOrNull(13).orEmpty(),
                                cast = cols.getOrNull(14).orEmpty(),
                                director = cols.getOrNull(15).orEmpty(),
                                durationLabel = cols.getOrNull(16).orEmpty(),
                                trailerUrl = cols.getOrNull(17).orEmpty(),
                                addedTimestamp = cols.getOrNull(18)?.toLongOrNull() ?: 0L,
                                seriesId = cols.getOrNull(19).orEmpty()
                            )
                        )
                        if (!firstBatchDispatched && result.size == FIRST_BATCH_SIZE && onFirstBatchReady != null) {
                            firstBatchDispatched = true
                            onFirstBatchReady.invoke(ArrayList(result))
                        }
                    }
                }
            }
            line = reader.readLine()
        }
        return result
    }

    private suspend fun loadLegacyJsonCache(
        file: File,
        maxLimit: Int,
        defaultSourceType: ContentSourceType,
        onFirstBatchReady: (suspend (List<Channel>) -> Unit)?
    ): List<Channel> {
        val result = ArrayList<Channel>(2048)
        val categoryPool = HashMap<String, String>(128)
        var firstBatchDispatched = false

        JsonReader(BufferedReader(InputStreamReader(NetworkClient.openDecompressedStream(FileInputStream(file)), Charsets.UTF_8), 32768)).use { reader ->
            if (reader.peek() != JsonToken.BEGIN_ARRAY) {
                file.delete()
                return emptyList()
            }
            reader.beginArray()
            var idx = 0
            while (reader.hasNext() && idx < maxLimit) {
                if (idx % 1000 == 0) coroutineContext.ensureActive()
                if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                    reader.skipValue()
                    continue
                }
                idx++
                var id = ""
                var num = idx
                var name = ""
                var category = "Live TV"
                var streamUrl = ""
                var logoUrl = ""
                var epgId = ""
                var backupUrl = ""

                reader.beginObject()
                while (reader.hasNext()) {
                    when (reader.nextName()) {
                        "i" -> id = readStr(reader)
                        "n" -> num = readInt(reader, idx)
                        "t" -> name = readStr(reader)
                        "c" -> {
                            val rawCat = readStr(reader, "Live TV").ifBlank { "Live TV" }
                            category = categoryPool.getOrPut(rawCat) { rawCat }
                        }
                        "u" -> streamUrl = readStr(reader)
                        "l" -> logoUrl = readStr(reader)
                        "e" -> epgId = readStr(reader)
                        "b" -> backupUrl = readStr(reader)
                        else -> reader.skipValue()
                    }
                }
                reader.endObject()

                if (streamUrl.isNotEmpty()) {
                    result.add(
                        Channel(
                            id = id.ifBlank { "ch_$idx" },
                            number = if (num > 0) num else idx,
                            name = name.ifBlank { "Channel $idx" },
                            category = category,
                            streamUrl = streamUrl,
                            logoUrl = logoUrl,
                            epgId = epgId,
                            backupUrl = backupUrl,
                            sourceType = defaultSourceType
                        )
                    )
                    if (!firstBatchDispatched && result.size == FIRST_BATCH_SIZE && onFirstBatchReady != null) {
                        firstBatchDispatched = true
                        onFirstBatchReady.invoke(ArrayList(result))
                    }
                }
            }
            while (reader.hasNext()) {
                reader.skipValue()
            }
            reader.endArray()
        }
        return result
    }

    fun totalCacheSizeBytes(): Long {
        return try {
            appContext.filesDir.listFiles { f ->
                f.isFile && f.name.startsWith(CACHE_PREFIX) && f.name.endsWith(".json")
            }?.sumOf { it.length() } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun enforceCacheBounds(keepFile: File) {
        try {
            val files = appContext.filesDir.listFiles { f ->
                f.isFile && f.name.startsWith(CACHE_PREFIX) && f.name.endsWith(".json")
            }?.sortedByDescending { it.lastModified() } ?: return

            var totalBytes = 0L
            files.forEachIndexed { index, f ->
                totalBytes += f.length()
                if (f != keepFile && (index >= MAX_CACHE_FILES || totalBytes > MAX_TOTAL_CACHE_BYTES)) {
                    f.delete()
                }
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to enforce cache bounds", e)
        }
    }

    suspend fun clearCache(key: String) {
        ramCacheByKey.remove(key)
        withContext(Dispatchers.IO) {
            cacheMutex.withLock {
                runCatching {
                    val file = cacheFileFor(key)
                    if (file.exists()) file.delete()
                }
                Unit
            }
        }
    }

    suspend fun clearAllCaches() {
        ramCacheByKey.clear()
        withContext(Dispatchers.IO) {
            cacheMutex.withLock {
                runCatching {
                    appContext.filesDir.listFiles()?.forEach { f ->
                        if (f.name.startsWith(CACHE_PREFIX) || f.name.endsWith(".tmp")) {
                            f.delete()
                        }
                    }
                }
                Unit
            }
        }
    }

    private fun readStr(reader: JsonReader, default: String = ""): String {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.STRING, JsonToken.NUMBER -> reader.nextString()
            JsonToken.BOOLEAN -> reader.nextBoolean().toString()
            else -> {
                reader.skipValue()
                default
            }
        }
    }

    private fun readInt(reader: JsonReader, default: Int): Int {
        return when (reader.peek()) {
            JsonToken.NULL -> {
                reader.nextNull()
                default
            }
            JsonToken.NUMBER -> runCatching { reader.nextInt() }.getOrElse {
                runCatching { reader.nextString().toIntOrNull() ?: default }.getOrDefault(default)
            }
            JsonToken.STRING -> reader.nextString().toIntOrNull() ?: default
            else -> {
                reader.skipValue()
                default
            }
        }
    }
}
