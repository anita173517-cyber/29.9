package com.harindra.iptvpro.vod

import android.content.Context
import android.content.Intent

/**
 * Safe Intent launcher & payload codec for [VodPlayerActivity].
 * Keeps Movie and Series navigation strictly decoupled from Live TV player state.
 */
object VodPlayerLauncher {
    const val EXTRA_CONTENT_TYPE = "vod_content_type"
    const val EXTRA_CONTENT_ID = "vod_content_id"
    const val EXTRA_STREAM_URL = "vod_stream_url"
    const val EXTRA_TITLE = "vod_title"
    const val EXTRA_SUBTITLE_LINE = "vod_subtitle_line"
    const val EXTRA_CATEGORY = "vod_category"
    const val EXTRA_POSTER_URL = "vod_poster_url"
    const val EXTRA_BACKDROP_URL = "vod_backdrop_url"
    const val EXTRA_RATING = "vod_rating"
    const val EXTRA_RELEASE_YEAR = "vod_release_year"
    const val EXTRA_DURATION_LABEL = "vod_duration_label"
    const val EXTRA_CONTAINER_EXT = "vod_container_ext"
    const val EXTRA_RESUME_MS = "vod_resume_ms"
    const val EXTRA_ACCOUNT_SCOPE = "vod_account_scope"
    const val EXTRA_SERIES_KEY = "vod_series_key"
    const val EXTRA_SERIES_ID = "vod_series_id"
    const val EXTRA_SERIES_TITLE = "vod_series_title"
    const val EXTRA_SEASON_NUMBER = "vod_season_number"
    const val EXTRA_EPISODE_NUMBER = "vod_episode_number"
    const val EXTRA_EPISODES_JSON = "vod_episodes_json"
    const val EXTRA_EXTERNAL_SUB_URL = "vod_ext_sub_url"
    const val EXTRA_EXTERNAL_SUB_LANG = "vod_ext_sub_lang"

    const val RESULT_RETURN_ACTION = "vod_return_action"
    const val RESULT_LAST_CONTENT_ID = "vod_last_content_id"
    const val RESULT_LAST_SERIES_KEY = "vod_last_series_key"
    const val RESULT_LAST_SEASON = "vod_last_season"
    const val ACTION_BACK_TO_DETAILS = "BACK_TO_DETAILS"
    const val ACTION_EXIT_TO_LIVE_TV = "EXIT_TO_LIVE_TV"

    fun createIntent(context: Context, payload: VodLaunchPayload): Intent {
        return Intent(context, VodPlayerActivity::class.java).apply {
            putExtra(EXTRA_CONTENT_TYPE, payload.contentType.code)
            putExtra(EXTRA_CONTENT_ID, payload.contentId)
            putExtra(EXTRA_STREAM_URL, payload.streamUrl)
            putExtra(EXTRA_TITLE, payload.title)
            putExtra(EXTRA_SUBTITLE_LINE, payload.subtitleLine)
            putExtra(EXTRA_CATEGORY, payload.category)
            putExtra(EXTRA_POSTER_URL, payload.posterUrl)
            putExtra(EXTRA_BACKDROP_URL, payload.backdropUrl)
            putExtra(EXTRA_RATING, payload.rating)
            putExtra(EXTRA_RELEASE_YEAR, payload.releaseYear)
            putExtra(EXTRA_DURATION_LABEL, payload.durationLabel)
            putExtra(EXTRA_CONTAINER_EXT, payload.containerExtension)
            putExtra(EXTRA_RESUME_MS, payload.resumePositionMs.coerceAtLeast(0L))
            putExtra(EXTRA_ACCOUNT_SCOPE, payload.accountScope.ifBlank { "default" })
            putExtra(EXTRA_SERIES_KEY, payload.seriesKey)
            putExtra(EXTRA_SERIES_ID, payload.seriesId)
            putExtra(EXTRA_SERIES_TITLE, payload.seriesTitle)
            putExtra(EXTRA_SEASON_NUMBER, payload.seasonNumber)
            putExtra(EXTRA_EPISODE_NUMBER, payload.episodeNumber)
            if (payload.episodes.isNotEmpty()) {
                putExtra(EXTRA_EPISODES_JSON, VodEpisodeNavItem.encodeList(payload.episodes))
            }
            if (payload.externalSubtitleUrl.isNotBlank()) {
                putExtra(EXTRA_EXTERNAL_SUB_URL, payload.externalSubtitleUrl)
                putExtra(EXTRA_EXTERNAL_SUB_LANG, payload.externalSubtitleLanguage)
            }
        }
    }

    fun parsePayload(intent: Intent?): VodLaunchPayload? {
        if (intent == null) return null
        val url = intent.getStringExtra(EXTRA_STREAM_URL)?.trim().orEmpty()
        val id = intent.getStringExtra(EXTRA_CONTENT_ID)?.trim().orEmpty()
        if (url.isEmpty() || id.isEmpty()) return null
        return VodLaunchPayload(
            contentType = VodContentType.fromCode(intent.getStringExtra(EXTRA_CONTENT_TYPE)),
            contentId = id,
            streamUrl = url,
            title = intent.getStringExtra(EXTRA_TITLE)?.trim().orEmpty().ifBlank { "VOD Playback" },
            subtitleLine = intent.getStringExtra(EXTRA_SUBTITLE_LINE).orEmpty(),
            category = intent.getStringExtra(EXTRA_CATEGORY).orEmpty(),
            posterUrl = intent.getStringExtra(EXTRA_POSTER_URL).orEmpty(),
            backdropUrl = intent.getStringExtra(EXTRA_BACKDROP_URL).orEmpty(),
            rating = intent.getStringExtra(EXTRA_RATING).orEmpty(),
            releaseYear = intent.getStringExtra(EXTRA_RELEASE_YEAR).orEmpty(),
            durationLabel = intent.getStringExtra(EXTRA_DURATION_LABEL).orEmpty(),
            containerExtension = intent.getStringExtra(EXTRA_CONTAINER_EXT).orEmpty(),
            resumePositionMs = intent.getLongExtra(EXTRA_RESUME_MS, 0L).coerceAtLeast(0L),
            accountScope = intent.getStringExtra(EXTRA_ACCOUNT_SCOPE).orEmpty().ifBlank { "default" },
            seriesKey = intent.getStringExtra(EXTRA_SERIES_KEY).orEmpty(),
            seriesId = intent.getStringExtra(EXTRA_SERIES_ID).orEmpty(),
            seriesTitle = intent.getStringExtra(EXTRA_SERIES_TITLE).orEmpty(),
            seasonNumber = intent.getIntExtra(EXTRA_SEASON_NUMBER, 0),
            episodeNumber = intent.getIntExtra(EXTRA_EPISODE_NUMBER, 0),
            episodes = VodEpisodeNavItem.decodeList(intent.getStringExtra(EXTRA_EPISODES_JSON)),
            externalSubtitleUrl = intent.getStringExtra(EXTRA_EXTERNAL_SUB_URL).orEmpty(),
            externalSubtitleLanguage = intent.getStringExtra(EXTRA_EXTERNAL_SUB_LANG).orEmpty().ifBlank { "en" }
        )
    }
}
