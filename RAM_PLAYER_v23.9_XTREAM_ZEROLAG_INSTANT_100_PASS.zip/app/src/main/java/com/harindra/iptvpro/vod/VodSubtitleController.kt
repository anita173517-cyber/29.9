package com.harindra.iptvpro.vod

import android.graphics.Typeface
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView

/**
 * Dedicated TV-Readable Subtitle Styling & Preference Controller for VOD Playback.
 */
@OptIn(UnstableApi::class)
class VodSubtitleController(
    private val prefs: VodPreferencesStore
) {
    fun applyStylingToPlayerView(playerView: PlayerView) {
        val subtitleView = playerView.subtitleView ?: return
        val fontSize = prefs.getSubtitleFontSize()
        val preset = prefs.getSubtitleStylePreset()

        val captionStyle = CaptionStyleCompat(
            preset.foregroundColor,
            preset.backgroundColor,
            0x00000000,
            CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
            preset.edgeColor,
            Typeface.SANS_SERIF
        )
        subtitleView.setStyle(captionStyle)
        subtitleView.setFractionalTextSize(fontSize.fractionalSize)
        subtitleView.setApplyEmbeddedStyles(false)
        subtitleView.setApplyEmbeddedFontSizes(false)
        subtitleView.setBottomPaddingFraction(0.08f)
    }

    fun applyDefaultSubtitlePreference(player: ExoPlayer) {
        val enabled = prefs.isSubtitlesDefaultEnabled()
        val preferredLang = prefs.getPreferredSubtitleLanguage()
        val builder = player.trackSelectionParameters.buildUpon()
        if (!enabled) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            if (preferredLang.isNotBlank() && preferredLang != "auto") {
                builder.setPreferredTextLanguage(preferredLang)
            }
        }
        player.trackSelectionParameters = builder.build()
    }

    fun adjustSubtitleDelayMs(deltaMs: Int): Int {
        val updated = (prefs.getSubtitleDelayMs() + deltaMs).coerceIn(-5000, 5000)
        prefs.setSubtitleDelayMs(updated)
        return updated
    }

    fun resetSubtitleDelay(): Int {
        prefs.setSubtitleDelayMs(0)
        return 0
    }

    fun getSubtitleDelayLabel(): String {
        val ms = prefs.getSubtitleDelayMs()
        return when {
            ms == 0 -> "0 ms (In Sync)"
            ms > 0 -> "+${ms} ms"
            else -> "${ms} ms"
        }
    }
}
