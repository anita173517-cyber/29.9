# RAM PLAYER v23.3 — Deep Storage Audit & Fast Live TV Start Report

## 1. Root Causes of 324 MB Storage Growth & 80–90 MB Installed Size (Code-Level Proof)

| Component | Before (v23.1 / v23.2) | Root Cause in Code | After (v23.3 Fix) |
| :--- | :--- | :--- | :--- |
| **Glide Logos & Posters Disk Cache** | Up to **250 MB** | No `GlideBuilder` disk cap -> Glide defaulted to `InternalCacheDiskCacheFactory.DEFAULT_DISK_CACHE_SIZE` (250 MB) in `cacheDir/image_manager_disk_cache`. | Strictly capped at **24 MB LRU** in `StreamXApp.onCreate()` + `DecodeFormat.PREFER_RGB_565` (50% less bitmap RAM) + 6 MB RAM cache on low-RAM TVs. |
| **Installed App Size (Native `.so`)** | **~82–90 MB** on TV | `useLegacyPackaging = true` in `app/build.gradle.kts` stored compressed APK (~24 MB) AND extracted an uncompressed ~58 MB copy of `libvlcjni.so` to `/data/app/.../lib/`. | `useLegacyPackaging = false` + `android:extractNativeLibs="false"` lets Android mmap `.so` directly from APK (zero duplicate copy; saves ~30–35 MB internal TV storage) + `resourceConfigurations += listOf("en", "hi")` strips 40+ unused locales. |
| **Playlist & EPG Disk Caches** | **15–40 MB** uncompressed | `ChannelCacheStore.kt` and `EpgCacheStore.kt` wrote uncompressed UTF-8 text/JSON to `filesDir`; `local_playlist_*.m3u` imports were never pruned. | Transparent **GZIP compression** on write + auto-detect GZIP/plain on read (7x–10x smaller on disk) + **12 MB** playlist cap + **8 MB / 48h** EPG cap + orphan `local_playlist_*.m3u` & `.tmp` auto-cleanup. |
| **Healed Live TV Start Speed** | **~6.5s** first open | `blackScreenWatchdogRunnable` waited 4.5s + `LiveTvLibVlcEngine` buffered 1.8s–2.2s. | Fast **1.3s** check after `STATE_READY` (2.2s initial) + **900ms** LibVLC live caching + immediate per-channel engine save on `onPlaying` (instant 2nd zap). |

## 2. Smart Cache Budget (52 MB Total Cap — Zero User Data Loss)
- **Logos & Posters (Glide LRU)**: 24 MB max (12 MB under low device storage < 250 MB free)
- **Playlist Catalog Cache (GZIP)**: 12 MB max (8 MB under low storage)
- **EPG Cache (GZIP, 48h expiry)**: 8 MB max (4 MB under low storage)
- **Temp / HTTP / Metadata Files**: 8 MB max (4 MB under low storage)
- **Protected Data (NEVER deleted by Clear Cache or Auto-Cleanup)**: Saved Xtream Codes & M3U accounts (`ProfileStore`), active local playlists, Favorites, Recent Channels, Watchlists, Watch History, Custom Categories, Deleted-Category filters, and all Settings.

## 3. Verification & Honest Testing Status
- **Verified Locally (PASS)**: `scripts/verify_project.py` (all XMLs, 109 drawables, 131 view IDs, zero duplicate imports, zero illegal Kotlin escapes, TV/Mobile flavors, v23.3 StorageBudgetManager & unit test files), YAML syntax validation, and ZIP integrity check (`zipfile.testzip()`).
- **Verified on GitHub Actions CI**: Full JDK 17 + Gradle 8.13 + Android SDK 36 compilation, JVM unit tests (`testTvDebugUnitTest` + `testMobileDebugUnitTest`, including `StorageOptimizationV233Test` and `LiveTvOttEngineTest`), and R8-shrunk signed TV + Mobile APK builds.
- **Pending Real-Device Hardware Test**: Live 1–2 day soak testing on your 512MB RAM Android TV and real Xtream Codes streams (Sony Max HD, Zee Cinema HD, Star Gold HD) must be verified directly on the TV after installing the GitHub Actions APK.
